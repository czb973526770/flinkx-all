package com.ysj;

/**
 * @author yihua.huang@dianping.com
 */
public interface HelloWorldService {

	void helloWorld();
}
