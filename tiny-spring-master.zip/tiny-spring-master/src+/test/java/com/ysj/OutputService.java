package com.ysj;

/**
 * @author yihua.huang@dianping.com
 */
public interface OutputService {
	void output(String text);
}
