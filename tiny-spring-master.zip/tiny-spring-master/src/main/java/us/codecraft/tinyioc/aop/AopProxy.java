package us.codecraft.tinyioc.aop;

/**
 * AOP代理
 * @author yihua.huang@dianping.com
 */
public interface AopProxy {

    Object getProxy();
}
