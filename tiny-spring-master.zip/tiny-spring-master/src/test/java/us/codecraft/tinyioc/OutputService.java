package us.codecraft.tinyioc;

/**
 * @author yihua.huang@dianping.com
 */
public interface OutputService {
    void output(String text);
}
